from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id = "",
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
    
    def _check_null(self, redshift_hook, table, col):
        query = f'SELECT count(*) FROM {table} WHERE {col} IS NULL'
        records = redshift_hook.get_records(query)
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. {table} returned no results")
        num_records = records[0][0]
        if num_records > 0:
            raise ValueError(f"Data quality check failed. {table}.{col} contained {num_records} not null rows")
        self.log.info(f"Data quality on table {table}.{col} check passed for not null columns")
        
    def _check_greater_than_zero(self, redshift_hook, table):
        query = f'SELECT count(*) FROM {table}'
        records = redshift_hook.get_records(query)
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. {table} returned no results")
        num_records = records[0][0]
        if num_records < 1:
            raise ValueError(f"Data quality check failed. {table} contained 0 rows")
        self.log.info(f"Data quality on table {table} check passed with {records[0][0]} records")

    def execute(self, context):
        self.log.info('Checking Not Null Columns')
        redshift_hook = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        
        for tbl, col in [('users', 'first_name'), ('users', 'last_name'), 
                     ('songs', 'title'), ('songs','artistid'),
                     ('artists', 'name')]:
            self._check_null(redshift_hook, tbl, col)
        
        for tbl in ('users','songs','artists','time'):
            self._check_greater_than_zero(redshift_hook, tbl)

                                           
        
        